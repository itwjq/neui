<?php 
global $wpdb;
global $current_user;
//用户个人中心网址
$usercenter_url = home_url()."/user-2/";
if(is_user_logged_in()){
    //用户登录
    wp_get_current_user();
    echo "<input type='hidden' name='post_author' value='{$current_user->ID}'>";
    echo "<input type='hidden' id='login_name' value='{$current_user->user_login}'>";
?>
<?php
}else{
    //用户没登录
    echo "<center><h2 class = 'jump'></h2></center>";
    jump_login();
}
?>
<!-- 引入百度编辑器 -->
    <!-- 加载编辑器的容器 -->
    <!-- 配置文件 -->
    <!-- <script type="text/javascript" src="<?php //echo home_url() ?>/wp-includes/editor/ueditor.config.js"></script> -->
    <!-- 编辑器源码文件 -->
    <!-- <script type="text/javascript" src="<?php //echo home_url()?>/wp-includes/editor/ueditor.all.js"></script> -->
    <!-- 实例化编辑器 -->
    <script type="text/javascript">
        // var ue = UE.getEditor('container');
    </script>
<!-- 以上引入百度编辑器 -->
<!-- <div style="height:300px;width:80%;">123</div> -->
<div style="width:80%;height:auto;margin:0 auto;">
<form action="" method="post" name="create_project_post" id="frontier_post" enctype="multipart/form-data">
    <ul id="myTab" class="nav nav-tabs">
        <li class="active">
            <a href="#basics" data-toggle="tab">基本内容</a></li>
        <li>
            <a href="#team" data-toggle="tab">项目团队</a></li>
        <li>
            <a href="#things" data-toggle="tab">用到的东西</a></li>    
        <li>
            <a href="#story" data-toggle="tab">详细描述</a></li>
        <li>
            <a href="#attachments" data-toggle="tab">附件</a></li>
        <li>
            <a href="#publish_setting" data-toggle="tab">发布设置</a></li>
    </ul>
    <div id="myTabContent" class="tab-content">
        <!-- 基本信息 -->
        <div class="tab-pane fade in active" id="basics">
            <div class="form-group">
                <label for="firstname" class="col-sm-2 control-label">项目名</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" value="" name="pro_title" placeholder="请输入项目名"><br>
                </div>
            </div>
            <div class="form-group">
                <label for="firstname" class="col-sm-2 control-label">摘要</label>
                <div class="col-sm-10">
                    <textarea class="form-control" rows="3" name="excerpt"></textarea><br>
                </div>
            </div>
            <div class="form-group">
                <label for="firstname" class="col-sm-2 control-label">项目演示视频网址(优酷)</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" value="" name="show_url" placeholder="请输入项目演示视频链接"><br>
                </div>
            </div>
            <div class="form-group">
                <label for="firstname" class="col-sm-2 control-label">
                    项目展示图片
                </label>
                <div class="col-sm-10">
                    <div class="panel panel-default" style='display:'>
                        <div class="panel-heading"></div>
                        <div class="panel-body">
                            <input type="file" name="pro_pic" value="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- 团队名称 -->
        <div class="tab-pane fade" id="team">
            <div class="form-group">
                <label for="firstname" class="col-sm-2 control-label">团队名称</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo ''; ?>" name="teamname" placeholder="请输入项目团队名称"></div>
            </div>

            <h4>　</h4>

            <div class="box-content">
                <div id="team-form" style="">
                    <div class="fields">
                        <table class="table table-condensed">
                            <thead>
                                <tr>
                                    <th style="width:40%">
                                        <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">用户</font></font>
                                    </th>
                                    <th style="display:none;">
                                        <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">允许</font></font>
                                    </th>
                                    <th style="width:40%">
                                        <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">贡献</font></font>
                                    </th>
                                    <th style="display:none;">
                                        <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">状态</font></font>
                                    </th>
                                    <th><font style="vertical-align: inherit;">操作</font></th>
                                </tr>
                            </thead>
                            <tbody id="pro_partners">
                                
                                <!-- 当前登录的用户 -->
                                <tr class="fields" name="partner_tem">
                                    <td style="width:40%">
                                        
                                        <a href="<?php echo $usercenter_url ?>">
                                                <font style="vertical-align: inherit;" name="pro_uname"><?php echo $current_user->user_login; ?></font>
                                                <input type="hidden" name="pro_user[]" value="<?php echo $current_user->user_ID; ?>" class="pro_uid">
                                        </a>
                                    </td>
                                    <td style="display:none;">
                                        <div class="form-group select optional base_article_team_members_permission_action">
                                            <select class="select optional form-control" name="" id="base_article_team_attributes_members_attributes_1_permission_action">
                                                <option value=""></option>
                                                <option selected="selected" value="manage">
                                                    <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">管理</font></font>
                                                </option>
                                                <option value="read">
                                                    <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">读</font></font>
                                                </option>
                                            </select>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-group text optional base_article_team_members_mini_resume"><textarea class="text optional form-control" maxlength="250" name="pro_userdo[]" ></textarea></div>
                                    </td>
                                    <td style="display:none;">
                                        <font style="vertical-align: inherit;"></font>
                                    </td>
                                    <td class="del_td">
                                        
                                    </td>
                                </tr>

                                <!-- 添加用户 -->
                                <tr class="fields">
                                    <td style="width:40%">
                                        <div class="form-group select optional base_article_team_members_user_id">
                                            <input type="text" class="search_input" placeholder="请您在这里输入用户名进行搜索" value='' style="margin-bottom:10px;">
                                            <select  class='teammate'>
                                                <option class = 'teammate_opt' disabled selected>
                                                    请输入用户名
                                                </option>
                                            </select>
                                        </div>
                                    </td>
                                    <td style="display:none;">
                                        <div class="form-group select optional base_article_team_members_permission_action">
                                            <select class="select optional form-control" name="" id="base_article_team_attributes_members_attributes_2_permission_action">
                                                <option value=""></option>
                                                <option selected="selected" value="manage">
                                                    <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(默认管理,功能不明确)</font></font>
                                                </option>
                                                <option value="read">
                                                    <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">读</font></font>
                                                </option>
                                            </select>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-group text optional base_article_team_members_mini_resume">
                                            <textarea class="text optional form-control" maxlength="250" name="" id="add_userdo"></textarea>
                                        </div>
                                    </td>
                                    <td style="display:none;">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;"></font>
                                        </font>
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>
                                <tr class="sortable-disabled">
                                    <td colspan="3"><a name="add_partner" class="btn btn-xs btn-success nested-field-table add_nested_fields" data-association="members" data-blueprint-id="team_members_fields_blueprint" href="javascript:void(0)"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">添加成员</font></font></a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <input type="hidden" value="89305" name="" id="base_article_team_attributes_id">
                    </div>
                </div>
            </div>
        </div>
        <!-- --------------------用到的东西-------------------- -->
        <div class="tab-pane fade" id="things">
            <div class="form-group">
                <label for="firstname" class="col-sm-2 control-label">项目硬件</label>
                <div class="col-sm-6">
                    <select name = 'hard' id = 'selhard'>
                        <option value="" disabled selected>请选择</option>
                        <?php 
                            if($res_hard){
                                foreach($res_hard as $v){
                        ?>
                            <option value = "<?php echo $v['id']?>" ><?php echo $v['name']?></option>
                        <?php }} ?>
                    </select>
                </div>
                <label for="firstname" class="col-sm-1 control-label">个数</label>
                <div class="col-sm-2">
                    <input type="number" id = 'h_num' name="num" value = '1' min = '1'>
                </div>
                <label class="col-sm-1 control-label" ID= 'addhard'>添加</label>
    
                <h5>　</h5>
                <div class = "col-sm-12" id = 'div_hard'> 

                    <?php 
                        if($isEdit){
                            foreach($res_hardthing as $value){
                                echo "<input style='margin-top:2px;' readonly type='text' class='hard{$value['id']}' name=hard[{$value['id']}] value='{$value['name']}-------x{$value['num']}' >";
                            }
                    ?>
                        <script type="text/javascript">
                            $("#div_hard").find('input').click(function(){
                                //取值
                                var val = $(this).attr('class').slice(4);
                                // alert(key);
                                remove(arr_choose, val);  
                                $(this).remove();
                            })
                        </script>
                    <?php }?>
                </div>

                <h5>　</h5>
                <label for="firstname" class="col-sm-2 control-label">项目软件</label>
                <div class="col-sm-9">
                    <select name = 'soft' class="form-control" id="selsoft" >
                        <option value="" disabled selected>请选择</option>
                        <?php 
                            if($res_soft){
                                foreach($res_soft as $v){
                        ?>
                            <option value = <?php echo $v['id']?>><?php echo $v['name']?></option>
                        <?php }} ?>
                    </select>
                </div>
                <label class="col-sm-1 control-label" ID= 'addsoft'>添加</label>
                <h5>　</h5>
                <div class = "col-sm-12" id = 'div_soft'> 
                    <?php 
                        if($isEdit){
                            foreach($res_softthing as $value){
                                echo "<input style='margin-top:2px;' readonly type='text' class='soft{$value['id']}' name=soft[{$value['id']}] value='{$value['name']}' >";
                            }
                    ?>
                    <script type="text/javascript">
                        $("#div_soft").find('input').click(function(){
                            //取值
                            var val = $(this).attr('class').slice(4);
                            // alert(key);
                            remove(arr_choose, val);  
                            $(this).remove();
                        })
                    </script>
                    <?php }?>
                </div>
            </div>

            <fieldset class="frontier_post_fieldset">
                <div align="center" style="padding-top:50px">
                    <!-- <input type="text" style="width:300px;height:20px;font-size:14pt;" placeholder="请输入硬件名称" id="hardware_input" onkeyup="autoComplete_hardware.start(event,'1','auto_hardware','things_hardware','things_hardware','http://127.0.0.1/wordpress/?json=hello.get_things&dev=1&name='+autoComplete_hardware.obj.value + '&type=1')"> -->
                    <div class="cpm-form-item cpm-project-role">
                    </div>
                </div>
                <div class="" id="auto_hardware">
                    <!--自动完成 DIV--></div>
                <div id="things_hardware">
                </div>
            </fieldset>
            
            <fieldset class="frontier_post_fieldset">
                
                <div class="" id="auto">
                    <!--自动完成 DIV--></div>
                <div id="things_software">
                </div>
            </fieldset>
            
        </div>
        <!-- --------------------详细描述-------------------- -->
        <div class="tab-pane fade" id="story">
            <fieldset class="frontier_post_fieldset">
                <legend>故事</legend>
                <div id="frontier_editor_field">
                    <script id="container" name="project_content" type="text/plain">
                        
                    </script>
                </div>
            </fieldset>
        </div>
        <div>
            <?php //echo $pro_content; ?>
        </div>
        <div class='content' style="display:none"><?php echo $pro_content; ?></div>
        <!-- --------------------附件-------------------- -->
        <div class="tab-pane fade" id="attachments">
            <?php //foreach($res_code as $value){ ?>
            <div class="panel panel-default">
                <div class="panel-heading">代码</div>
                <?php if($isEdit && $res_code){ ?>
                    <center class='pro_pic'><img title='双击修改代码图片' src="<?php echo home_url().'/wp-content'.$res_code[0]['path']?>"></center>
                    <div class="panel-body" style="display:none">
                        <div class="panel-body">
                            <input type="file" name="code_file1" value="">
                        </div>
                    </div>
                <?php } ?>
                <div class="panel-body" style="<?php if($isEdit && $res_code) echo "display:none"; ?>" >
                    <input type="file" name="code_file<?php if($isEdit && !$res_ylt) echo "1"; ?>" value="">
                    <!-- or<textarea name="code"></textarea> -->
                </div>
            </div>
            <?php //} ?>
            <?php //foreach($res_ylt as $value){ ?>
            <div class="panel panel-default">
                <div class="panel-heading">原理图和电路图</div>
                <?php if($isEdit && $res_ylt){ ?>
                    <center class='pro_pic'><img title='双击修改原理图' src="<?php echo home_url().'/wp-content'.$res_ylt[0]['path']?>"></center>
                    <div class="panel-body" style="display:none">
                        <input type="file" name="diagrams_file1" value="">
                    </div>
                <?php } ?>
                <div class="panel-body" style="<?php if($isEdit && $res_ylt) echo "display:none"; ?>" >
                    <input type="file" name="diagrams_file<?php if($isEdit && !$res_ylt) echo "1"; ?>" value="">
                </div>
            </div>
            <?php //} ?>
            <?php //foreach($res_cad as $value){ ?>
            <div class="panel panel-default">
                <div class="panel-heading">CAD - 外壳和定制部件</div>
                <?php if($isEdit && $res_cad){ ?>
                    <center class='pro_pic'><img title='双击修改图片' src="<?php echo home_url().'/wp-content'.$res_cad[0]['path']?>"></center>
                    <div class="panel-body" style="display:none">
                        <input type="file" name="cad_file1" value="">
                    </div>
                <?php } ?>
                <div class="panel-body" style="<?php if($isEdit && $res_cad) echo "display:none"; ?>">
                    <input type="file" name="cad_file<?php if($isEdit && !$res_ylt) echo "1"; ?>" value="">
                </div>
            </div>
            <?php //} ?>
        </div>
        <!-- --------------------发布设置-------------------- -->
        <div class="tab-pane fade" id="publish_setting">
            <h2>进展</h2>
            <div class="radio">
                <label>
                    <input type="radio" name="progress" value="wip" <?php if ($isEdit && $res_pro[0]['progress'] == 'wip') echo 'checked'; ?>> <p>我仍在研究我的项目</p>
                </label>
            </div>
            <div class="radio">
                <label>
                    <input type="radio" name="progress" value="select_tuto" <?php if(!$isEdit) echo 'checked'; ?> <?php if ($isEdit && $res_pro[0]['progress'] == 'select_tuto') echo 'checked'; ?>> <p>我的项目已完成</p>
                </label>
            </div>

            <h2>难度</h2>
            <div class="form-group">
                <select class="form-control" name="difficulty" id="difficulty123">
                    <?php foreach($res_diff as $k=>$v){ ?>
                        <option value = "<?php echo $v['diff_value'] ?>" <?php if(isset($selected_arr[$v['diff_value']])) echo $selected_arr[$v['diff_value']] ?> ><?php echo $v['diff_name'] ?></option>
                    <?php } ?>
                </select>
            </div>

            <h2>所需时间</h2>
            
            <div class="form-group form-inline">
                <input type="text" class="form-control" name="duration" placeholder="请输入时间" value="<?php echo $pro_period; ?>"><span>　小时</span>
            </div>  
            
            <h2>许可证</h2>
            <div class="form-group">
                <select class="form-control" name="license">
                    <?php
                        foreach($res_license as $value){
                            if($pro_license == $value['name']) 
                                echo "<option selected>{$value['name']}</option>";
                            else
                                echo "<option>{$value['name']}</option>";
                        } 
                    ?>
                </select>
            </div>
    
    
            <h2>查看权限</h2>
            <div class="radio">
                <label>
                    <input type="radio" name="post_status" value="private" <?php if ($isEdit && $res_pro[0]['post_status'] == 'private') echo 'checked'; ?>> <p>加密(只有自己可见)</p>
                </label>
            </div>
            <div class="radio">
                <label>
                    <input type="radio" name="post_status" value="publish" <?php if(!$isEdit) echo 'checked'; ?> <?php if ($isEdit && $res_pro[0]['post_status'] == 'publish') echo 'checked'; ?>> <p>公共</p>
                </label>
            </div>
            <div class="radio" style="display: none">
                <label>
                    <input type="radio" name="post_status" value="draft" > <p>草稿</p>
                </label>
            </div>

            <button class="btn btn-primary btn-lg pull-right" type="submit" name="user_post_submit" id="user_post_publish"  value="publish">发布项目</button>

        </div>
    </div>
</form>
<div style="font: 0px/0px sans-serif;clear: both;display: block"> </div>
<script src=<?php echo ARTICLE_CREATE_URL;?>/js/project-create.js></script>
<script>
    var plugin_url = "<?php echo ARTICLE_CREATE_URL;?>";
</script>
</div>
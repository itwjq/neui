//实时搜索
$("body").on("input porpertychange",".search_input",function(){
    // var thisTxt=$("#name").val();
    // $(this).siblings("p").html(thisTxt);
    var userIN = $(this).val();
    // console.log(userIN);
    //获取字符超过三个开始搜索
    if(userIN.length<4){
        $(".teammate").find(".teammate_opt").text("请继续输入");
    }else{
        $(".teammate").find(".teammate_opt").text("正在搜索,请稍后...");
        var get_ajax = $.ajax({
            type:"POST",
            url:plugin_url+"/get_results.php",
            data:{'do':'getusers','username':userIN},
            success:function(data){
                // users = $.parseJSON(data);
                users = eval('('+data+')');
                console.log(users);
                var option = $("<option></option>");
                for(var i = 0;i<users.length;i++){
                    console.log(users[i]);
                    var clone_opt = option.clone();
                    clone_opt.text(user[i][user_login]);
                    console.log(clone_opt);

                }
            }
        },'json');
        // get_ajax.abort();
    }
});
//添加成员
$("a[name='add_partner']").click(function(){
    alert();
}); 